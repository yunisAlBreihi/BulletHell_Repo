#include "SpriteVertex.h"

VAO SpriteVertex::vao = VAO();