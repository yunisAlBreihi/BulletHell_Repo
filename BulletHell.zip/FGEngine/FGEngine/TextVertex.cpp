#include "TextVertex.h"

VAO TextVertex::vao = VAO();