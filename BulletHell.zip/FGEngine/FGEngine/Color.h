#pragma once
#include "float4.h"
typedef float4 Color;