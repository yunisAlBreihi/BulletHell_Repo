#include "LineVertex.h"

VAO LineVertex::vao = VAO();