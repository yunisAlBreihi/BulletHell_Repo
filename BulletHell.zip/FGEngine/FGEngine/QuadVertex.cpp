#include "QuadVertex.h"


VAO QuadVertex::vao = VAO();
