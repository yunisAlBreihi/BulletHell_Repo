#include "StartScreen.h"

StartScreen::StartScreen()
{

}

StartScreen::~StartScreen()
{

}

void StartScreen::Update()
{

}

void StartScreen::Render()
{

}