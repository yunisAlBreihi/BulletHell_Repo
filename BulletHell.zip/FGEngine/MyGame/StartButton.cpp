#include "StartButton.h"

StartButton::StartButton(FG::Sprite sprite) : sprite(sprite)
{
}

void StartButton::Start(FG::Vector2D startPos, int index)
{
}

void StartButton::Update(float deltaTime)
{
}

void StartButton::Render(Renderer* renderer)
{
}
